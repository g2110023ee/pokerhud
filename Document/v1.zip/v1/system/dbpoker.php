<?php
class DbPdo {
	//ローカルテスト
	private static $testInstance = NULL;
	private static $testDsn      = "mysql:unix_socket=/tmp/mysql.sock; dbname=pokerhud";
	private static $testDb_user  = 'pokerhud';
	private static $testDb_pass  = 'test';
	//本番
	private static $instance = NULL;
	private static $dsn      = "mysql:host=localhost; dbname=pokerhud";
	private static $db_user  = '';
	private static $db_pass  = '';
	
	private function __construct()
	{

	}
	private function __clone()
	{

	}
	//本番
	public static function getInstance() {

		if (!self::$instance)
		{
			$options = array(
  			  PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
			); 
			self::$instance = new PDO(self::$dsn, self::$db_user, self::$db_pass,$options);
			self::$instance-> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
		return self::$instance;
	}
	//ローカルテスト
	public static function testGetInstance() {
	
		if (!self::$testInstance)
		{
			self::$testInstance = new PDO(self::$testDsn, self::$testDb_user, self::$testDb_pass);
			self::$testInstance-> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
		return self::$testInstance;
	}
	
	
	/**
	 * SQLを取得する
	 *
	 * @param $file	SQL文を格納したファイルパス
	 * @return string		SQL文
	 */
	public function getSql($file){
		// ファイルオープン
		if(is_file($file) === FALSE){
			//Syslogに投げる
		}
		$fp = fopen($file, "r");
	
		// ファイル内容を変数に格納
		$sql = "";
		while(feof($fp) != 1){
			$line = trim(fgets($fp));
			$ary = explode("--", $line);
			if(strlen($ary[0])>0){
				$sql .= $ary[0]."\n";
			}
		}
		fclose($fp);
		return $sql;
	}
	
	/**
	 * function facebookCheck
	 * 入力されたログインIDに対応するPASSをDBから検索し
	 * 該当するものがあればPASSを返す。
	 * @param String $fbid
	 * @return String 
	 */
	public static function facebookCheck($fbid){
		// 初期化＋準備SQL発行
		//$pdo = self::getInstance();
        $pdo = self::testGetInstance();
	
		$stmt = $pdo->prepare(self::getSql(dirname(__FILE__)."/sql/s_facebook.sql"));
		$stmt->bindValue(":fbid", $fbid);
		if($stmt->execute() !== true){
            echo "nohit";
		}
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		$userName = array($row['username']);
        if($userName[0]==null){
            return false;
        }
		return $userName[0];
	}

    /**
	 * function reguser
	 * 入力されたログインIDに対応するPASSをDBから検索し
	 * 該当するものがあればPASSを返す。
	 * @param String $fbid
	 * @return String 
	 */
    public static function reguser($fbid,$username){
		// 初期化＋準備SQL発行
		//$pdo = self::getInstance();
        $pdo = self::testGetInstance();
		// 入稿データを新規追加
		$stmt = $pdo -> query("SET NAMES utf8;");
		$stmt = $pdo->prepare(self::getSql(dirname(__FILE__)."/sql/i_facebook.sql"));
		$stmt->bindValue(":fbid", $fbid);
		$stmt->bindValue(":username", $username);
		if($stmt->execute() !== true){
            return false;
		}
        return true;
    }
}