INSERT IGNORE INTO hudtbl (fbid,username) 
VALUES (:fbid,:username)
