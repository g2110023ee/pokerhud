<?php
require_once dirname(__FILE__).'/system/dbpoker.php';
if(isset($_GET["fid"])&&ctype_digit($_GET["fid"])) {
    $facebookId = $_GET["fid"];
    if(strlen($facebookId)!=16){
        $array = array(
            "statusCode" => "400" ,
            "msg" => array(
                "error" => "No Get Worng" ,
            ),
        );
        echo json_encode( $array );
    }else{
        $username = DbPdo::facebookCheck($facebookId);
        if($username ==false){
            $array = array(
                "statusCode" => "404" ,
                "msg" => array(
                    "error" => "No User" ,
                ),
            );
            echo json_encode( $array );
        }else{
            $array = array(
                "statusCode" => "200" ,
                "msg" => array(
                    "username" => $username ,
                ),
            );
            echo json_encode( $array );
        }
    }
}else{
    $json_string = file_get_contents('php://input');
    if($json_string != null){
        $jdon_obj = json_decode($json_string);
        $facebookId = $jdon_obj->fbid;
        $username = $jdon_obj->username;
        if(strlen($facebookId)!=16||$username.lenght>=15){
            $array = array(
                "statusCode" => "400" ,
                "msg" => array(
                    "error" => "Username is so long" ,
                ),
            );
            echo json_encode( $array );
        }else{
            if(DbPdo::regUser($facebookId,$username)){
                $array = array(
                "statusCode" => "200" ,
                "msg" => array(
                    "result" => "OK" ,
                ),
            );
            echo json_encode( $array );
            }
        }
    }else{
    $array = array(
        "statusCode" => "400" ,
        "msg" => array(
            "error" => "No input Wornging" ,
        ),
    );
    echo json_encode( $array );
    }   
    
}